library(testthat)
library(rrvgo)

test_check("rrvgo")
